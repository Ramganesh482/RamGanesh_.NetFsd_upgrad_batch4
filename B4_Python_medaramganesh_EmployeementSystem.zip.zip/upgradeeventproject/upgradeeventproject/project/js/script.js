// ================================
// DATABASE (IndexedDB)
// ================================

let db;

let request = indexedDB.open("UpgradEventsDB", 1);

request.onupgradeneeded = function(event){
    db = event.target.result;

    if(!db.objectStoreNames.contains("events")){
        db.createObjectStore("events",{keyPath:"id"});
    }
};

request.onsuccess = function(event){
    db = event.target.result;
    displayEvents();
};

request.onerror = function(){
    console.log("Database error");
};


// ================================
// LOGIN
// ================================

function login(){

let email = document.getElementById("email").value.trim();
let password = document.getElementById("password").value.trim();

if(email === "" || password === ""){
    alert("Please enter email and password");
    return false;
}

if(email === "admin@upgrad.com" && password === "12345"){

    localStorage.setItem("login", "true");

    alert("Login Successful");

    window.location.href = "events.html";

}else{

    alert("Invalid login credentials");

}

return false;
}


// ================================
// CHECK LOGIN
// ================================

function checkLogin(){
if(localStorage.getItem("login") !== "true"){
    alert("Please login first");
    window.location.href = "login.html";
}
}


// ================================
// LOGOUT
// ================================

function logout(){
localStorage.removeItem("login");
window.location.href="login.html";
}


// ================================
// ADD EVENT
// ================================

function addEvent(){

let event={
id:document.getElementById("id").value,
name:document.getElementById("name").value,
category:document.getElementById("category").value,
date:document.getElementById("date").value,
time:document.getElementById("time").value,
url:document.getElementById("url").value
};

let transaction=db.transaction(["events"],"readwrite");
let store=transaction.objectStore("events");

store.add(event);

transaction.oncomplete=function(){

alert("Event Added Successfully");
displayEvents();

// clear form
document.getElementById("id").value = "";
document.getElementById("name").value = "";
document.getElementById("category").value = "";
document.getElementById("date").value = "";
document.getElementById("time").value = "";
document.getElementById("url").value = "";

};

}


// ================================
// DISPLAY EVENTS
// ================================

function displayEvents(){

let container=document.getElementById("eventList");

if(!container) return;

container.innerHTML="";

let transaction=db.transaction(["events"],"readonly");
let store=transaction.objectStore("events");

store.openCursor().onsuccess=function(event){

let cursor=event.target.result;

if(cursor){

let e=cursor.value;

container.innerHTML+=`
<div class="col-md-4">
<div class="card p-3 m-2 shadow">

<h5>${e.name}</h5>

<p><b>ID:</b> ${e.id}</p>
<p><b>Category:</b> ${e.category}</p>
<p><b>Date:</b> ${e.date}</p>
<p><b>Time:</b> ${e.time}</p>

<a href="${e.url}" target="_blank" class="btn btn-primary mb-2">
Join Event
</a>

<button onclick="deleteEvent('${e.id}')" class="btn btn-danger">
Delete
</button>

</div>
</div>
`;
cursor.continue();
}
};
}


// ================================
// DELETE EVENT
// ================================

function deleteEvent(id){

let transaction=db.transaction(["events"],"readwrite");
let store=transaction.objectStore("events");

store.delete(id);

transaction.oncomplete=function(){
displayEvents();
};

}


// ================================
// SEARCH EVENT
// ================================

function searchEvent(){

let searchId = document.getElementById("searchId").value.toLowerCase();
let searchName = document.getElementById("searchName").value.toLowerCase();
let searchCategory = document.getElementById("searchCategory").value;

let container = document.getElementById("eventList");

container.innerHTML = "";

let transaction = db.transaction(["events"], "readonly");
let store = transaction.objectStore("events");

let found = false;

store.openCursor().onsuccess = function(event){

    let cursor = event.target.result;

    if(cursor){

        let e = cursor.value;

        if(
            (searchId === "" || e.id.toLowerCase().includes(searchId)) &&
            (searchName === "" || e.name.toLowerCase().includes(searchName)) &&
            (searchCategory === "" || e.category === searchCategory)
        ){

            found = true;

            container.innerHTML += `
            <div class="col-md-4">
            <div class="card p-3 m-2 shadow">

            <h5>${e.name}</h5>

            <p><b>ID:</b> ${e.id}</p>
            <p><b>Category:</b> ${e.category}</p>
            <p><b>Date:</b> ${e.date}</p>
            <p><b>Time:</b> ${e.time}</p>

            <a href="${e.url}" target="_blank" class="btn btn-primary">
            Join Event
            </a>

            </div>
            </div>
            `;
        }

        cursor.continue();
    }
    else{
        if(!found){
            container.innerHTML = "<p class='text-danger'>No events found</p>";
        }
    }
};
}


// ================================
// CONTACT FORM
// ================================

function contactSubmit() {
    alert("Your query has been submitted successfully!");
    document.querySelector("form").reset();
}


// ================================
// EVENT REGISTRATION (NEW)
// ================================

function registerEvent(){

let fname = document.getElementById("fname").value.trim();
let lname = document.getElementById("lname").value.trim();
let email = document.getElementById("email").value.trim();

if(fname === "" || lname === "" || email === ""){
    alert("Please fill all fields");
    return;
}

alert("You are successfully registered to this event!");

// clear form
document.getElementById("fname").value = "";
document.getElementById("lname").value = "";
document.getElementById("email").value = "";

}